# Validation

- 28 automated checks passed for message and job warning rules, destination parsing, benign messages, local history, deletion, backup merging, and storage failures.
- JavaScript syntax, required offline assets, JSON manifests, and Android XML were checked.
- Chrome UI exercised: message example to result; link user-info destination (evil.example); job-fee example; history search; backup export and restore; safety tips; navigation.
- English screenshot recognition extracted the included OTP-message fixture, then identified four warning signs.
- Layouts inspected at 320 x 667, 390 x 844, and 430 x 932; navigation fitted and no horizontal overflow was found.
- Native Android compilation/device behavior is unverified because the Android SDK and JDK compiler are not installed here. No APK is included.
- Browser service-worker offline installation was not exercised on the non-HTTPS preview origin. The native project bundles all assets, and the source build generates an offline cache manifest for localhost/HTTPS use.

The test fixture is synthetic. No user messages or screenshots are bundled as history.

## Version 2.1 layout update

- Desktop card now measures 520 px wide and follows content height (about 682 px in the large preview).
- Home controls are 20–27 px below the description in the checked layouts.
- 320 x 667, 390 x 844 and 1280 x 688 layouts were inspected; no horizontal overflow.
- Message form submit button was visible without scrolling in the desktop preview.
- The cat was visibly captured mid-blink in the actual app image on both phone layouts.
- JavaScript/manifest checks and the source build passed. Checking rules and local-history code are unchanged.

## Version 2.2 phone update

- Checked 320 x 667, 390 x 844 and 430 x 932 phone layouts: all seven labeled controls fit; no horizontal overflow.
- Phone label starts 20–26 px below the coral section.
- Tap targets measured at least 73 x 60 px on the small phone and 88 x 68 px on the regular phone.
- Message and job forms fill the phone viewport; submit buttons were visible without scrolling.
- Message example still produces the expected four-warning result.
- Desktop retains its seven-icon row. The checking engine, storage and screenshot reader are unchanged.

## Version 2.3 spacing adjustment

- Reduced only the phone home heading and moved its options about 23 px lower in the checked 390 x 844 view.
- All seven options remain visible, with no horizontal overflow.

## Version 2.4 visual balance

- Inspected 320 x 667, 390 x 844 and 390 x 780 layouts.
- All seven options fit in the viewport, with no horizontal overflow.
- Options panel follows the description with 28–48 px spacing.
- Header, label contrast and the options group were visually checked in Chrome.

## Version 2.5 color update

- Web and Android primary theme colors use #EF3340 (239, 51, 64).
- Launcher SVG and PNG assets were updated; PNG color values and Android XML were checked.
- The red phone theme was visually inspected at 390 x 844.

## Version 2.6 black and red theme

- Sampled the supplied reference: #1D1D1D charcoal and #E73938 red.
- Home, message form, settings and high-concern result were visually inspected in Chrome at 390 x 844.
- The message example still produces the expected four-warning result.
- Checked dark inputs, caret, focus states, labels and result details; the checking rules and local-data logic are unchanged.
- Updated Android system-bar colors and launcher assets; native compilation remains unverified.

## Version 2.7 white buttons and cat

- Inspected the white cat, paws, navigation icons and message/settings action buttons in Chrome.
- Checked home at 320 x 667 and 390 x 844; no horizontal overflow and all seven options remain visible.
- Kept the existing cat SVG shape and blink animation, including reduced-motion support.
- Updated launcher SVG/PNG assets and Android vector colors; SVG and Android XML parse successfully.
- JavaScript/manifest/asset checks and the web build passed. The checking engine, storage and OCR files are unchanged.
- Native Android compilation remains unverified; no APK is included.

## Version 2.8 cat eye correction

- Visually inspected the corrected dark oval eyes and small white highlights in the actual app at 390 x 844.
- Verified the cat silhouette, blink CSS, paws and layout stylesheet are identical to version 2.7.
- Web and Android launcher mascots use the matching eye treatment; SVG and Android vector XML parse successfully.
- JavaScript/manifest/asset checks and the web build passed. Native compilation remains unverified.

## Version 2.9 paws at panel ends

- Checked the two paws at 320 px and 390 px phone widths and the 520 px desktop panel.
- Both paws sit approximately 1.1 px from their respective panel edge after rotation.
- Visually inspected the actual phone app at 390 x 844.
- JavaScript/manifest/asset checks and the web build passed. Cat artwork, eyes and blinking are unchanged.

## Version 2.10 connected paw placement

- Inspected actual phone and desktop screens together after anchoring the paws to the cat width.
- Checked 320 x 667 and 390 x 844 phones, plus 600 x 844 and 600 x 688 desktop viewports.
- Paw centers track the cat side anchors within 0.02 px across all four sizes; no horizontal overflow.
- JavaScript/manifest/asset checks and the web build passed. Existing cat artwork, blink animation and all other assets are unchanged.

## Version 2.11 local phone preview

- Local preview opens the actual app in a 390 x 844 phone frame. All seven options and the Home button were exercised in Chrome.
- The message example produced the expected four-warning result inside the phone frame.
- Checked preview containers at 700 x 688 and 460 x 900: the entire phone fits with no overflow, and the app viewport remains 390 x 844.
- In-process request checks passed for the desktop frame, direct mobile app, preview assets, HEAD requests and path boundary protection.
- JavaScript/manifest/asset checks and the web build passed. The preview frame is outside web/ and is absent from Android assets and the offline app manifest.
- App styling, mascot assets, checking rules, storage and OCR files are unchanged. Native Android compilation remains unverified; no APK is included.

## Version 2.12 phone layout and photo input

- Bundled the official Montserrat variable font and OFL license locally; headings and body text use Montserrat.
- Removed the home offline-check label and all cross-checker tabs. Inspected home, message and job-offer screens at 390 x 844.
- Checked 320 x 667 and 430 x 932 home layouts: all seven controls fit, with no horizontal or vertical overflow.
- Selected the synthetic OTP photo through the message picker, read it locally, reviewed the extracted text, and obtained four message warnings.
- Selected a synthetic job advert through the job picker, read it locally, and obtained three job-offer warnings. The OCR read 5000 as SOOO, demonstrating why extracted text stays editable.
- All 28 engine/storage tests passed. JavaScript/manifest/assets checks and the web build passed.
- iPhone native photo-picker and Android compilation/device behavior are not device-tested here. Browser photo uploads and bundled OCR were exercised in Chrome.
