# 2.12.0

- Bundled Montserrat for all app text and reduced oversized phone headings.
- Rebalanced the home screen and removed the offline-check label.
- Added photo text reading directly to message and job-offer forms.
- Removed cross-checker tabs; photo text stays in its selected checker.

# 2.11.0

- Local preview on Mac opens the actual phone app in an interactive 390 × 844 device frame.
- Preview scales to fit the laptop window while keeping the app at phone dimensions.
- Mobile requests and native Android continue to open the full-screen app directly.
- The development frame stays outside the bundled app assets.

# 2.10.0

- Anchored the paws to the cat's sides using the same responsive width as the cat.
- Kept both paws connected as the desktop and phone mascot changes size.

# 2.9.0

- Moved the left and right paws to the two outer ends of the panel on phone and desktop.
- Preserved the existing white cat, corrected eyes and blinking.

# 2.8.0

- Replaced the hollow eye rings with slightly smaller dark oval eyes and small white highlights.
- Matched the launcher mascot eyes and preserved the existing blink animation.

# 2.7.0

- Made navigation and action buttons white with dark icons and text.
- Turned the cat and paws white, keeping the same shape, red nose and blink animation.
- Updated web and Android launcher mascots to match.
- Preserved the red and black layout, spacing and typography.

# 2.6.0

- Matched the supplied color reference: charcoal #1D1D1D and red #E73938.
- Applied dark backgrounds, white text and red accents to home, forms, history, scan, settings and results.
- Updated launcher icons, browser theme and Android system-bar colors.

# 2.5.0

- Replaced the pink/coral theme with Pantone Red 032 C screen reference #EF3340 (RGB 239, 51, 64).
- Updated web/Android theme colors, buttons, launcher icons and the cat nose to match.

Color references:
- https://www.pantone.com/color-finder/red-032-c
- https://ufmsecretariat.org/wp-content/uploads/2024/04/ufm_visualidentityguidelines_2024_EXT.pdf

# 2.4.0

- Rebalanced the phone header and vertical spacing.
- Grouped the seven options in one aligned panel.
- Improved brand and option-label contrast while keeping the smaller heading and blinking cat.

# 2.3.0

- Smaller home heading on phones.
- Phone options moved approximately 24 px lower.

# 2.2.0

- Phone heading starts immediately below the cat with consistent padding.
- Seven phone controls use two labeled rows, with 60–68 px tall tap areas.
- Phone forms use the viewport and respect safe-area spacing; the background stays still while a tool is open.
- Inputs use readable phone sizing; the original cat still blinks.
- Desktop keeps its previous single-row layout.

Stop the old server with Ctrl+C, open this folder in VS Code and run npm start. Keep the same localhost port to retain browser history.

# 2.1.0

- Wider desktop layout with natural heading proportions.
- Content sets the desktop card height; buttons sit close to the description.
- More room in forms and larger home controls.
- The original cat now blinks; reduced-motion preferences are respected.

To use the update, stop the previous server with Ctrl+C, open this folder in VS Code and run npm start. Keep the same localhost port to retain browser history.
