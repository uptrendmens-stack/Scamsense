import { analyze, KINDS, MAX_TEXT } from './engine.js';
import { createStore } from './storage.js';

const $ = selector => document.querySelector(selector);
const home = $('#home');
const sheet = $('#sheet');
const content = $('#sheet-content');
const backdrop = $('#sheet-backdrop');
let storage;
try { storage = window.localStorage; } catch { storage = null; }
const store = createStore(storage);
const drafts = { message: '', link: '', job: '' };
let result = null;
let resultBack = 'message';
let currentRoute = '';
let returnFocus = null;
let toastTimer;
let ocrWorker = null;
let ocrToken = 0;
let ocrLibrary;
const scan = { image: '', text: '', busy: false, status: '', progress: 0, error: '', kind: 'message', owner: 'scan' };
const validRoutes = [...KINDS, 'scan', 'history', 'safety', 'settings', 'result'];
const examples = {
  message: 'Your bank account is blocked. Send your OTP immediately to reactivate it. Do not tell anyone.',
  link: 'https://paypal.com.account-review.example/login',
  job: 'Work from home, no interview required. Pay a registration fee of Rs 5000 to unlock tasks and withdraw your earnings. Contact HR on Telegram.'
};
const KIND_LABEL = { message: 'Message', link: 'Link', job: 'Job offer' };
const LEVEL_LABEL = { high: 'High concern', medium: 'Needs caution', caution: 'Review the details', low: 'No obvious warning signs', unclear: 'More context needed' };
const RESULT_HEADINGS = {
  high: 'PAUSE BEFORE\nYOU PROCEED.',
  medium: 'TAKE A\nCLOSER LOOK.',
  caution: 'CHECK THE\nDETAILS.',
  low: 'NO OBVIOUS\nWARNING SIGNS.',
  unclear: 'A LITTLE MORE\nCONTEXT.'
};

function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(attrs)) {
    if (value === undefined || value === null || value === false) continue;
    if (key === 'class') node.className = value;
    else if (key === 'checked') node.checked = Boolean(value);
    else if (key.startsWith('on')) node.addEventListener(key.slice(2), value);
    else node.setAttribute(key, value === true ? '' : String(value));
  }
  for (const child of children.flat(Infinity)) {
    if (child === undefined || child === null || child === false) continue;
    node.append(child instanceof Node ? child : document.createTextNode(String(child)));
  }
  return node;
}
function icon(name) {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('aria-hidden', 'true');
  const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
  use.setAttribute('href', 'assets/icons.svg#' + name);
  svg.append(use);
  return svg;
}
function button(text, onClick, className = 'primary', glyph = 'arrow') {
  return el('button', { type: 'button', class: className, onclick: onClick }, el('span', {}, text), glyph && icon(glyph));
}
function heading(text) { return el('h2', { id: 'sheet-title', class: 'view-heading', tabindex: '-1' }, text); }
function notify(message) {
  clearTimeout(toastTimer);
  $('#toast').textContent = message;
  $('#toast').hidden = false;
  toastTimer = setTimeout(() => { $('#toast').hidden = true; }, 3800);
}
function navigate(route = '') {
  if (route === currentRoute && location.hash.slice(1) === route) renderRoute();
  else location.hash = route;
}
function goBack() {
  if (currentRoute === 'result') navigate(resultBack);
  else navigate('');
}
function cancelScan() {
  ocrToken++;
  if (ocrWorker) { ocrWorker.terminate().catch(() => {}); ocrWorker = null; }
  if (scan.busy) { scan.status = 'Reading cancelled. Choose another photo or use text.'; scan.progress = 0; }
  scan.busy = false;
}
function renderRoute() {
  let route = location.hash.slice(1);
  if (!validRoutes.includes(route)) route = '';
  if (route === 'result' && !result) route = '';
  if (currentRoute === scan.owner && route !== scan.owner && scan.busy) cancelScan();
  if (!currentRoute && route) returnFocus = document.activeElement;
  currentRoute = route;
  const open = Boolean(route);
  document.body.classList.toggle('tool-open', open);
  home.inert = open;
  home.setAttribute('aria-hidden', String(open));
  sheet.hidden = !open;
  backdrop.hidden = !open;
  content.replaceChildren();
  content.scrollTop = 0;
  if (!open) {
    document.title = 'ScamSense';
    if (returnFocus?.isConnected) returnFocus.focus({ preventScroll: true });
    return;
  }
  document.title = (KIND_LABEL[route] || ({ scan: 'Screenshot', history: 'Recent checks', safety: 'Safety tips', settings: 'Settings', result: 'Check result' })[route]) + ' · ScamSense';
  if (KINDS.includes(route)) renderCheck(route);
  else if (route === 'result') renderResult();
  else if (route === 'history') renderHistory();
  else if (route === 'settings') renderSettings();
  else if (route === 'safety') renderSafety();
  else if (route === 'scan') renderScan();
  requestAnimationFrame(() => $('#sheet-title')?.focus({ preventScroll: true }));
}
function renderPhotoCheck(kind) {
  const own = scan.owner === kind;
  const busy = own && scan.busy;
  const picker = el('input', { type: 'file', accept: 'image/*', hidden: true,
    'aria-label': 'Upload a ' + (kind === 'job' ? 'job offer' : 'message') + ' photo',
    onchange: () => { if (picker.files?.[0]) runScan(picker.files[0], kind); } });
  const upload = button('Upload photo', () => picker.click(), 'secondary', 'upload');
  upload.disabled = busy;
  const area = el('div', { class: 'photo-upload' }, picker, upload);
  if (own && scan.image) area.append(el('img', { src: scan.image, class: 'scan-preview', alt: 'Your selected ' + (kind === 'job' ? 'job offer' : 'message') + ' photo' }));
  if (own && scan.status) area.append(el('p', { id: 'scan-status', class: 'scan-status', role: 'status', 'aria-live': 'polite' }, scan.status));
  if (busy) area.append(el('progress', { id: 'scan-progress', max: 100, value: scan.progress, 'aria-label': 'Reading photo' }),
    button('Cancel reading', () => { cancelScan(); scan.status = 'Reading cancelled. You can upload another photo or type the text.'; renderCheck(kind); }, 'text-button', null));
  if (own && scan.error) area.append(el('p', { class: 'error', role: 'alert' }, scan.error));
  return area;
}
function renderOcrOwner() {
  if (currentRoute !== scan.owner) return;
  if (scan.owner === 'scan') renderScan();
  else { content.replaceChildren(); renderCheck(scan.owner); }
}
function showResult(text, kind, back = kind) {
  result = analyze(text, kind);
  resultBack = back;
  store.add(result);
  navigate('result');
}
function renderCheck(kind) {
  content.replaceChildren();
  const title = { message: 'CHECK A\nMESSAGE.', link: 'CHECK A\nLINK.', job: 'CHECK A\nJOB OFFER.' }[kind];
  const intro = {
    message: 'Paste a message or upload a photo to check it.',
    link: 'Check the address without opening the website.',
    job: 'Paste the offer or upload a photo of the job advert or recruiter conversation.'
  }[kind];
  const field = el('textarea', {
    id: 'check-input', rows: kind === 'link' ? 4 : 7, maxlength: MAX_TEXT,
    placeholder: kind === 'link' ? 'https://example.com' : 'Paste the text here…',
    autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false',
    'aria-describedby': 'check-error',
    oninput: () => {
      drafts[kind] = field.value;
      counter.textContent = field.value.length.toLocaleString() + ' / 20,000';
      error.hidden = true;
      field.removeAttribute('aria-invalid');
    },
    onkeydown: event => { if (event.key === 'Enter' && (event.ctrlKey || event.metaKey)) { event.preventDefault(); submit(); } }
  });
  field.value = drafts[kind];
  field.disabled = scan.owner === kind && scan.busy;
  const counter = el('span', { class: 'small muted' }, field.value.length.toLocaleString() + ' / 20,000');
  const error = el('p', { id: 'check-error', class: 'error', role: 'alert', hidden: true });
  function submit() {
    if (scan.owner === kind && scan.busy) return;
    try { drafts[kind] = field.value; showResult(field.value, kind); }
    catch (err) { error.textContent = err.message; error.hidden = false; field.setAttribute('aria-invalid', 'true'); field.focus(); }
  }
  const form = el('form', { onsubmit: event => { event.preventDefault(); submit(); } },
    el('label', { class: 'field-label', for: 'check-input' }, kind === 'link' ? 'Website address' : kind === 'job' ? 'Job offer text' : 'Message or email'),
    field,
    el('div', { class: 'field-meta' },
      el('button', { class: 'text-button', type: 'button', disabled: scan.owner === kind && scan.busy, onclick: () => {
        field.value = examples[kind]; drafts[kind] = field.value;
        field.dispatchEvent(new Event('input')); field.focus();
      } }, 'Try an example'), counter),
    error,
    el('button', { type: 'submit', class: 'primary', disabled: scan.owner === kind && scan.busy }, 'Check ' + (kind === 'job' ? 'offer' : kind), icon('arrow'))
  );
  content.append(heading(title), el('p', { class: 'view-intro' }, intro), kind !== 'link' && renderPhotoCheck(kind), form,
    el('p', { class: 'note' }, kind === 'link' ? 'The link stays unopened. This checks the address, not the website’s reputation.' : 'Your text is checked on this device. Nothing is sent to a server.'));
}
function renderResult() {
  const badge = el('span', { class: 'result-label ' + result.level }, icon(result.level === 'low' ? 'search' : 'alert'), LEVEL_LABEL[result.level]);
  const title = heading(RESULT_HEADINGS[result.level]);
  title.classList.add('result-heading');
  if (result.level === 'high') title.classList.add('coral');
  const count = result.findings.length;
  const explanation = count
    ? count + ' warning ' + (count === 1 ? 'sign found' : 'signs found') + ' in this ' + (result.kind === 'job' ? 'offer' : result.kind) + '.'
    : result.level === 'unclear' ? 'There is too little text for a useful check. Add the full message or offer.'
      : 'The offline rules did not find a known warning pattern. Verify the sender and context before acting.';
  content.append(badge, title, el('p', { class: 'result-count' }, explanation));
  if (count) {
    content.append(el('ul', { class: 'findings' }, result.findings.map(finding =>
      el('li', { class: 'finding' },
        el('p', { class: 'finding-title' }, finding.title),
        el('p', { class: 'finding-detail' }, finding.detail),
        finding.evidence && el('span', { class: 'evidence' }, finding.evidence)
      ))));
  }
  if (result.domains.length) {
    content.append(el('p', { class: 'section-label' }, 'Actual destination ' + (result.domains.length > 1 ? 'domains' : 'domain')),
      el('div', { class: 'domain-list' }, result.domains.map(domain => el('span', { class: 'domain' }, domain))));
  }
  content.append(el('p', { class: 'section-label' }, 'Before you act'),
    el('ul', { class: 'advice-list' }, result.recommendations.map(item => el('li', {}, item))),
    el('p', { class: 'note' }, result.limitation),
    el('details', { class: 'source-details' }, el('summary', {}, 'Text you checked'), el('div', { class: 'source-preview' }, result.text)),
    el('div', { class: 'button-stack' },
      button('Check something else', () => navigate(result.kind)),
      button('Share result', shareResult, 'secondary', 'copy')));
}
async function shareResult() {
  const text = 'ScamSense — ' + LEVEL_LABEL[result.level] + '\n\n' +
    (result.findings.length ? result.findings.map(f => '• ' + f.title).join('\n') : 'No known warning pattern found by the offline rules.') +
    '\n\n' + result.recommendations.join('\n') + '\n\n' + result.limitation;
  try {
    if (window.AppHost?.shareText) { window.AppHost.shareText(text); return; }
    if (navigator.share) { await navigator.share({ title: 'ScamSense check', text }); return; }
    if (navigator.clipboard?.writeText) { await navigator.clipboard.writeText(text); notify('Result copied.'); return; }
    const field = el('textarea', { 'aria-label': 'Copy result' }, text);
    content.append(field); field.select(); document.execCommand('copy'); field.remove(); notify('Result copied.');
  } catch (err) { if (err.name !== 'AbortError') notify('Sharing was unavailable. Try copying again.'); }
}
function renderHistory() {
  const search = el('input', { type: 'search', class: 'search-input', placeholder: 'Search your checks', 'aria-label': 'Search recent checks', oninput: () => drawRecords(search.value) });
  const list = el('ul', { class: 'history-list' });
  const empty = el('div', { class: 'empty-state' });
  content.append(heading('YOUR RECENT\nCHECKS.'), el('p', { class: 'view-intro' }, 'Saved on this device. Tap a check to see its warning signs.'),
    el('div', { class: 'search-wrap' }, icon('search'), search), empty, list);
  if (!store.settings.saveHistory) content.append(el('p', { class: 'note' }, 'Saving new checks is turned off in Settings.'));
  function drawRecords(query = '') {
    const records = store.records.filter(record => (record.text + ' ' + KIND_LABEL[record.kind]).toLocaleLowerCase().includes(query.toLocaleLowerCase()));
    list.replaceChildren();
    empty.replaceChildren();
    empty.hidden = Boolean(records.length);
    if (!records.length) {
      empty.append(el('div', { class: 'empty-icon' }, icon('history')),
        el('h3', {}, query ? 'NO MATCHES.' : 'A FRESH START.'),
        el('p', {}, query ? 'Try a different word or clear the search.' : 'Your saved checks will appear here. Start with a message, link, or job offer.'),
        !query && button('Check a message', () => navigate('message')));
      return;
    }
    for (const record of records) {
      const date = new Date(record.createdAt).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
      const open = el('button', { type: 'button', class: 'history-open', onclick: () => {
        try { result = analyze(record.text, record.kind); resultBack = 'history'; navigate('result'); }
        catch { notify('This check could not be reopened.'); }
      } },
      el('span', { class: 'history-top' }, el('span', {}, KIND_LABEL[record.kind]), el('time', { datetime: record.createdAt }, date)),
      el('span', { class: 'history-text' }, record.text),
      el('span', { class: 'history-level ' + record.level }, LEVEL_LABEL[record.level]));
      const remove = el('button', { type: 'button', class: 'plain-icon', 'aria-label': 'Delete ' + KIND_LABEL[record.kind].toLowerCase() + ' check', onclick: () => { store.remove(record.id); drawRecords(search.value); notify('Check deleted.'); } }, icon('trash'));
      list.append(el('li', { class: 'history-item' }, open, remove));
    }
  }
  drawRecords();
}
function renderSettings() {
  const toggle = el('input', { type: 'checkbox', class: 'toggle', checked: store.settings.saveHistory, id: 'save-history', onchange: () => {
    store.setSaveHistory(toggle.checked);
    if (!store.persistent) notify('Storage is unavailable. Changes last for this session only.');
  } });
  const backupInput = el('input', { type: 'file', accept: '.json,application/json', hidden: true, 'aria-label': 'Choose a backup', onchange: async () => {
    const file = backupInput.files?.[0];
    if (!file) return;
    try {
      if (file.size > 4 * 1024 * 1024) throw new Error('This backup is too large.');
      const count = store.import(await file.text());
      notify(count + ' saved ' + (count === 1 ? 'check' : 'checks') + ' available.');
    } catch (err) { notify(err.message === 'This backup is too large.' ? err.message : 'Choose a valid ScamSense v2 backup.'); }
    backupInput.value = '';
  } });
  const confirm = el('div', { class: 'confirmation', hidden: true },
    el('p', {}, 'Delete all saved checks on this device?'),
    el('div', { class: 'confirmation-actions' },
      el('button', { type: 'button', onclick: () => { confirm.hidden = true; } }, 'Keep checks'),
      el('button', { type: 'button', class: 'confirm-delete', onclick: () => { store.clear(); confirm.hidden = true; notify('All saved checks deleted.'); } }, 'Delete all')));
  content.append(heading('YOUR DEVICE.\nYOUR DATA.'),
    el('p', { class: 'view-intro' }, 'No account. No uploads. Your checks stay with you.'),
    el('div', { class: 'setting-row' }, el('label', { for: 'save-history' },
      el('p', { class: 'setting-title' }, 'Save check history'),
      el('p', { class: 'setting-description' }, 'Keep up to 100 recent checks on this device.')), toggle),
    el('div', { class: 'setting-row' }, el('div', {},
      el('p', { class: 'setting-title' }, 'Offline screenshot reader'),
      el('p', { class: 'setting-description' }, 'English text recognition is included. Images are processed locally and are not saved in history.'))),
    el('div', { class: 'button-stack' },
      button('Export saved checks', exportBackup, 'secondary', 'download'),
      button('Import a backup', () => backupInput.click(), 'secondary', 'upload'),
      button('Delete all saved checks', () => { confirm.hidden = false; confirm.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }, 'danger-button', 'trash')),
    backupInput, confirm,
    ...(store.persistent ? [] : [el('p', { class: 'note' }, 'This browser has blocked storage. Checks can only be kept until you close the app.')]),
    el('p', { class: 'note' }, 'Exported backups contain the text of your saved checks. Keep them private.'),
    el('p', { class: 'version' }, 'ScamSense 2.12.0 · Local rules v2.0\nEnglish screenshot recognition · No trackers or paid APIs'));
}
function exportBackup() {
  const backup = store.export();
  if (window.AppHost?.saveBackup) { window.AppHost.saveBackup(backup); return; }
  const url = URL.createObjectURL(new Blob([backup], { type: 'application/json' }));
  const anchor = el('a', { href: url, download: 'ScamSense-Backup-' + new Date().toISOString().slice(0, 10) + '.json' });
  document.body.append(anchor); anchor.click(); anchor.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
  notify('Backup prepared.');
}
function renderSafety() {
  const tips = [
    ['Keep private codes private.', 'Do not send a one-time code, PIN, password, or recovery phrase to someone who contacts you unexpectedly. Use the organization’s official app to check the request.'],
    ['Find your own way back.', 'For a bank, delivery, or account alert, use an app or address you already trust. A logo, display name, or HTTPS padlock does not verify the sender.'],
    ['Verify the employer.', 'Find the vacancy through the employer’s own careers page. Verify recruitment contacts and early requests for money or identity documents before responding.'],
    ['Pause before sending money.', 'Pressure, secrecy, unexpected prizes, guaranteed returns, and requests for gift cards are reasons to stop and verify through a separate trusted contact.'],
    ['If you already shared something.', 'Stop responding. Contact your bank or account provider through its official channel, change affected passwords, and keep evidence of the conversation.'],
    ['What this check can tell you.', 'ScamSense looks for warning patterns in the text and link address you provide. It does not authenticate a sender, visit a website, inspect redirects, or access live reputation lists.']
  ];
  content.append(heading('A SMALL PAUSE.\nA SMART MOVE.'),
    el('p', { class: 'view-intro' }, 'A few habits to keep close when something feels off.'),
    ...tips.map(([title, text], index) => el('details', { class: 'tip', open: index === 0 }, el('summary', {}, title), el('p', {}, text))));
}
function renderScan() {
  content.replaceChildren();
  const picker = el('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp,image/bmp', hidden: true, 'aria-label': 'Choose a screenshot', onchange: () => { if (picker.files?.[0]) runScan(picker.files[0]); } });
  const upload = el('div', { class: 'upload-zone' }, icon('scan'),
    el('p', {}, scan.image ? 'Choose another screenshot to start again.' : 'Choose a screenshot of a message or offer.'),
    button(scan.image ? 'Choose another image' : 'Choose a screenshot', () => picker.click(), 'primary', 'upload'));
  if (scan.busy) upload.querySelector('button').disabled = true;
  const status = el('p', { id: 'scan-status', class: 'scan-status', role: 'status', 'aria-live': 'polite' }, scan.status);
  const progress = el('progress', { id: 'scan-progress', max: 100, value: scan.progress, 'aria-label': 'Reading screenshot', hidden: !scan.busy });
  content.append(heading('READ IT.\nTHEN CHECK IT.'),
    el('p', { class: 'view-intro' }, 'Read English text from a screenshot, entirely on your device.'),
    picker, upload);
  if (scan.image) content.append(el('img', { src: scan.image, class: 'scan-preview', alt: 'Your selected screenshot' }));
  content.append(status, progress);
  if (scan.busy) content.append(button('Cancel reading', () => { cancelScan(); scan.status = 'Reading cancelled. Choose an image to try again.'; renderScan(); }, 'secondary', 'close'));
  if (scan.error) content.append(el('p', { class: 'error', role: 'alert' }, scan.error));
  if (scan.text && !scan.busy) {
    const text = el('textarea', { id: 'scan-text', rows: 6, maxlength: MAX_TEXT, 'aria-label': 'Extracted text', spellcheck: 'false', oninput: () => { scan.text = text.value; } });
    text.value = scan.text;
    const select = el('select', { id: 'scan-kind', class: 'inline-select', 'aria-label': 'Check extracted text as', onchange: () => { scan.kind = select.value; } },
      KINDS.map(kind => el('option', { value: kind }, KIND_LABEL[kind])));
    select.value = scan.kind;
    content.append(el('label', { class: 'field-label', for: 'scan-text' }, 'Review the extracted text'), text,
      el('p', { class: 'note' }, 'Correct any reading errors before checking.'),
      el('label', { class: 'field-label', for: 'scan-kind' }, 'Check this as'), select,
      button('Check extracted text', () => {
        try { scan.text = text.value; showResult(text.value, scan.kind, 'scan'); }
        catch (err) { notify(err.message); }
      }));
  }
  content.append(el('p', { class: 'note' }, 'PNG, JPG, WebP or BMP · Up to 10 MB. Your image is never uploaded.'));
}
async function loadOcr() {
  if (window.Tesseract) return window.Tesseract;
  if (!ocrLibrary) ocrLibrary = new Promise((resolve, reject) => {
    const script = el('script', { src: 'vendor/ocr/tesseract.min.js' });
    script.onload = () => resolve(window.Tesseract);
    script.onerror = () => { ocrLibrary = null; script.remove(); reject(new Error('The local text reader could not load. Open the app through npm start and try again.')); };
    document.head.append(script);
  });
  return ocrLibrary;
}
async function prepareImage(file) {
  const image = new Image();
  const url = URL.createObjectURL(file);
  try {
    image.src = url;
    await image.decode();
    const scale = Math.min(1, 2200 / Math.max(image.naturalWidth, image.naturalHeight));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
    const ctx = canvas.getContext('2d', { alpha: false });
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
    return await new Promise((resolve, reject) => canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('The image could not be read.')), 'image/png'));
  } finally { URL.revokeObjectURL(url); }
}
async function runScan(file, owner = 'scan') {
  if (!file.type.startsWith('image/') && !/\.(png|jpe?g|webp|bmp|heic|heif)$/i.test(file.name)) { notify('Choose a PNG, JPG, WebP or BMP screenshot.'); return; }
  if (file.size > 10 * 1024 * 1024) { notify('Choose an image smaller than 10 MB.'); return; }
  cancelScan();
  const token = ++ocrToken;
  if (scan.image) URL.revokeObjectURL(scan.image);
  Object.assign(scan, { owner, image: URL.createObjectURL(file), text: '', error: '', status: 'Starting the private text reader…', progress: 0, busy: true });
  renderOcrOwner();
  let worker;
  let timer;
  try {
    timer = setTimeout(() => {
      if (token !== ocrToken) return;
      cancelScan();
      scan.error = 'This image took too long to read. Try cropping it to the message.';
      scan.status = ''; renderOcrOwner();
    }, 90000);
    const Tesseract = await loadOcr();
    const image = await prepareImage(file);
    if (token !== ocrToken) return;
    const workerPromise = Tesseract.createWorker('eng', 1, {
      workerPath: new URL('vendor/ocr/worker.min.js', document.baseURI).href,
      corePath: new URL('vendor/ocr/', document.baseURI).href,
      langPath: new URL('vendor/ocr/', document.baseURI).href,
      workerBlobURL: false, gzip: false, cacheMethod: 'none',
      legacyCore: false, legacyLang: false,
      logger: event => {
        if (token !== ocrToken) return;
        scan.status = event.status === 'recognizing text' ? 'Reading text on your device…' : 'Preparing the offline text reader…';
        scan.progress = event.status === 'recognizing text' ? Math.round(event.progress * 100) : 0;
        const status = $('#scan-status'); const progress = $('#scan-progress');
        if (status) status.textContent = scan.status;
        if (progress) progress.value = scan.progress;
      }
    });
    worker = await workerPromise;
    if (token !== ocrToken) { await worker.terminate(); return; }
    ocrWorker = worker;
    const output = await worker.recognize(image);
    if (token !== ocrToken) return;
    scan.text = (output.data.text || '').trim().slice(0, MAX_TEXT);
    if (!scan.text) scan.error = 'No readable text found. Try a clearer or more closely cropped screenshot.';
    if (scan.text && owner !== 'scan') drafts[owner] = scan.text;
    scan.status = scan.text ? 'Text extracted. Review it before checking.' : '';
  } catch (err) {
    if (token === ocrToken) { scan.error = 'The screenshot could not be read. Try a clearer image or paste its text instead.'; scan.status = ''; }
    console.error('Local screenshot reading failed:', err.message);
  } finally {
    clearTimeout(timer);
    if (worker) await worker.terminate().catch(() => {});
    if (ocrWorker === worker) ocrWorker = null;
    if (token === ocrToken) { scan.busy = false; renderOcrOwner(); }
  }
}
$('#sheet-back').addEventListener('click', goBack);
$('#sheet-close').addEventListener('click', () => navigate(''));
backdrop.addEventListener('click', () => navigate(''));
window.addEventListener('hashchange', renderRoute);
document.addEventListener('keydown', event => {
  if (!currentRoute) return;
  if (event.key === 'Escape') { event.preventDefault(); goBack(); return; }
  if (event.key === 'Tab') {
    const focusable = [...sheet.querySelectorAll('a,button,input,textarea,select,summary,[tabindex="0"]')].filter(node => !node.disabled && node.getClientRects().length);
    if (!focusable.length) return;
    const first = focusable[0], last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  }
});
window.ScamSense = {
  back() { if (!currentRoute) return false; goBack(); return true; },
  receiveText(value) {
    const text = String(value || '').slice(0, MAX_TEXT);
    const kind = /^(?:https?:\/\/|www\.)\S+$/i.test(text.trim()) ? 'link' : 'message';
    drafts[kind] = text; navigate(kind);
  },
  async receiveImage(dataUrl, name) {
    try {
      const parts = /^data:(image\/(?:png|jpeg|webp|bmp));base64,([a-zA-Z0-9+/=]+)$/.exec(dataUrl);
      if (!parts || parts[2].length > 14 * 1024 * 1024) throw new Error('Unsupported image');
      const bytes = Uint8Array.from(atob(parts[2]), char => char.charCodeAt(0));
      const blob = new Blob([bytes], { type: parts[1] });
      navigate('scan');
      await new Promise(resolve => requestAnimationFrame(resolve));
      await runScan(new File([blob], name || 'shared-screenshot.png', { type: blob.type }));
    } catch { notify('The shared screenshot could not be opened. Choose it from your images.'); }
  },
  notify
};
renderRoute();
if ('serviceWorker' in navigator && !window.AppHost && /https?:/.test(location.protocol)) {
  navigator.serviceWorker.register('./sw.js').catch(err => console.warn('Offline cache was unavailable:', err.message));
}
