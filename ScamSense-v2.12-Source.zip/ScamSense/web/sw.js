/* Only bundled static files enter this cache. User input and images are never cached. */
const CACHE_PREFIX = 'scamsense-offline-';
const BUILD_VERSION = '88031d2887e1';
let activeCache;
async function manifest() {
  const response = await fetch(new URL('precache.json', self.registration.scope), { cache: 'no-store' });
  if (!response.ok) throw new Error('Offline manifest unavailable');
  return response.json();
}
self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const data = await manifest();
    activeCache = CACHE_PREFIX + BUILD_VERSION;
    const cache = await caches.open(activeCache);
    await cache.addAll(data.files.map(file => new URL(file, self.registration.scope).href));
    await self.skipWaiting();
  })());
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    if (!activeCache) {
      const names = (await caches.keys()).filter(name => name.startsWith(CACHE_PREFIX));
      activeCache = names[names.length - 1];
    }
    for (const name of await caches.keys()) if (name.startsWith(CACHE_PREFIX) && name !== activeCache) await caches.delete(name);
    await self.clients.claim();
  })());
});
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.origin !== self.location.origin) return;
  event.respondWith((async () => {
    if (event.request.mode === 'navigate') {
      try { return await fetch(event.request); }
      catch { return (await caches.match(new URL('index.html', self.registration.scope))) || Response.error(); }
    }
    try { const response = await fetch(event.request); if (!response.ok) throw new Error('Asset unavailable'); return response; }
    catch { return (await caches.match(event.request)) || Response.error(); }
  })());
});
