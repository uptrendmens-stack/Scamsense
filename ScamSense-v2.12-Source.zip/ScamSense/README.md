# ScamSense 2.12

ScamSense phone app in black and red, with white buttons and the white blinking cat from your reference. The design folder holds the original visual references. Montserrat is bundled locally for every app font. The current app uses charcoal #1D1D1D, red #E73938 and white #FFFFFF.

## Preview the phone app in VS Code

Install free Node.js 18 or newer. Open this folder, then use the terminal:

    npm start

Open **http://localhost:5173** on your Mac. It shows the actual app inside an interactive 390 × 844 phone frame that fits your screen. All seven options work inside the phone preview. No npm install, account, API key, subscription, or paid dependency is needed.

In VS Code with Chrome installed, you can also press **F5** to start and debug the phone preview. The frame is only a local development tool. Android loads the app itself at full screen, with no frame or browser controls. Mobile browsers opening the local server also receive the app directly.

## Included

- Message, link, and job-offer checks with explanations.
- Screenshot text recognition, with the English model and all three CPU variants bundled locally.
- Local history, search, individual deletion, history toggle, and backup import/export.
- Accessible buttons, keyboard navigation, phone layouts, and reduced-motion support.
- Offline assets and Android source using the same interface and checking code.

Message and job-offer screens each offer photo upload with offline English text reading. Extracted text stays in that checker and can be edited before checking.

The seven round buttons are **message, link, job, screenshot, history, safety, settings**.

## Android

The android folder contains a complete Android Gradle project: Java source, launcher icon, sharing support, file import, and backup export. Open it in Android Studio and use a local Gradle 8.9 installation, or build from this folder:

    npm run android:build

Requires **JDK 17**, **Android SDK Platform 35**, and SDK build tools. Set ANDROID_HOME, or let Android Studio create android/local.properties. The helper downloads Gradle 8.9 from its official source and checks its SHA-256 on the first build. Build dependencies need internet initially; the installed app uses bundled assets and requests no internet permission.

The debug APK is written to build/ScamSense-2.12.0-debug.apk. A native APK is **not included**: this environment has no Android SDK/JDK compiler, so the native build has not been run or device-tested. The phone interface and screenshot reader have been exercised in Chrome.

The gradlew launchers call the included Node helper. They are not the standard Gradle Wrapper JAR. For Android Studio, use a local Gradle 8.9 distribution.

## Check and build

    npm test
    npm run check
    npm run build

The build command refreshes the offline asset manifest and creates a dist folder for local checks. Android uses the shared web/ assets directly. The development phone frame lives in tools/phone-preview and is excluded from the Android assets and offline app cache.

## What the checks mean

ScamSense uses transparent local rules, not a cloud AI model. It finds warning signs; it cannot authenticate a sender or guarantee that a message is safe. Link checking never opens the link, follows redirects, or queries a live reputation service. No warning signs is not a safety certificate.

Screenshot reading supports English. Review extracted text before checking it. Screenshots are never uploaded or saved in history. Text history stays in local storage; uninstalling or clearing app/browser data removes it. Export a backup first to keep it.

No advertisements, analytics, trackers, remote fonts, or CDN dependencies are included.
