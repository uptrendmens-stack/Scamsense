import { access, mkdir, readFile, writeFile, copyFile } from 'node:fs/promises';
import { createWriteStream, createReadStream } from 'node:fs';
import { createHash } from 'node:crypto';
import { homedir } from 'node:os';
import { resolve, join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { spawnSync } from 'node:child_process';
const root = fileURLToPath(new URL('..', import.meta.url));
const android = resolve(root, 'android');
const version = '8.9';
const windows = process.platform === 'win32';
const cache = join(homedir(), '.cache', 'scamsense-build');
const gradle = join(cache, 'gradle-' + version, 'bin', windows ? 'gradle.bat' : 'gradle');
const exists = async path => { try { await access(path); return true; } catch { return false; } };
function run(command, args, options = {}) {
  const result = spawnSync(command, args, { cwd: android, stdio: 'inherit', ...options });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(command + ' exited with code ' + result.status);
}
try {
  const java = process.env.JAVA_HOME ? join(process.env.JAVA_HOME, 'bin', windows ? 'java.exe' : 'java') : 'java';
  const javaCheck = spawnSync(java, ['-version'], { encoding: 'utf8' });
  if (javaCheck.error || javaCheck.status) throw new Error('Install JDK 17, or use Android Studio’s bundled JDK, before building Android.');
  const javaVersion = (javaCheck.stderr || javaCheck.stdout).match(/version "(\d+)/);
  if (!javaVersion || Number(javaVersion[1]) < 17) throw new Error('Android builds require JDK 17 or newer.');
  let sdk = process.env.ANDROID_HOME || process.env.ANDROID_SDK_ROOT || '';
  const localProperties = join(android, 'local.properties');
  if (!sdk && await exists(localProperties)) {
    sdk = ((await readFile(localProperties, 'utf8')).match(/^sdk\.dir=(.+)$/m)?.[1] || '').trim().replace(/\\:/g, ':').replace(/\\\\/g, '\\');
  }
  if (!sdk || !await exists(join(sdk, 'platforms', 'android-35', 'android.jar'))) {
    throw new Error('Install Android SDK Platform 35 in Android Studio, then set ANDROID_HOME or let Android Studio write android/local.properties.');
  }
  run(process.execPath, [join(root, 'tools', 'build.mjs'), '--android']);
  if (!await exists(gradle)) {
    await mkdir(cache, { recursive: true });
    const zip = join(cache, 'gradle-' + version + '-bin.zip');
    const base = 'https://services.gradle.org/distributions/gradle-' + version + '-bin.zip';
    console.log('Downloading official Gradle ' + version + ' (one-time build dependency)…');
    const checksumResponse = await fetch(base + '.sha256');
    if (!checksumResponse.ok) throw new Error('Could not obtain the official Gradle checksum.');
    const expected = (await checksumResponse.text()).trim().toLowerCase();
    if (!/^[a-f0-9]{64}$/.test(expected)) throw new Error('The official checksum was not valid.');
    const response = await fetch(base);
    if (!response.ok || !response.body) throw new Error('Gradle download failed. Check your connection and retry.');
    await pipeline(Readable.fromWeb(response.body), createWriteStream(zip));
    const hash = createHash('sha256');
    for await (const chunk of createReadStream(zip)) hash.update(chunk);
    if (hash.digest('hex') !== expected) throw new Error('Gradle checksum mismatch. The download was not used.');
    if (windows) {
      const script = join(cache, 'unpack-gradle.ps1');
      await writeFile(script, 'param([string]$Archive,[string]$Destination)\nExpand-Archive -LiteralPath $Archive -DestinationPath $Destination -Force\n');
      run('powershell.exe', ['-NoProfile', '-NonInteractive', '-File', script, zip, cache]);
    } else run('unzip', ['-q', '-o', zip, '-d', cache]);
  }
  if (windows) run('cmd.exe', ['/d', '/s', '/c', '"' + gradle + '" --no-daemon assembleDebug']);
  else run(gradle, ['--no-daemon', 'assembleDebug']);
  const source = join(android, 'app', 'build', 'outputs', 'apk', 'debug', 'app-debug.apk');
  const output = join(root, 'build', 'ScamSense-2.12.0-debug.apk');
  await mkdir(dirname(output), { recursive: true });
  await copyFile(source, output);
  console.log('APK ready: ' + output);
} catch (error) {
  console.error('\nAndroid build: ' + error.message);
  process.exitCode = 1;
}
