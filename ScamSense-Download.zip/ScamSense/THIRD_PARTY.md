# Bundled components

All runtime dependencies are bundled. No CDN requests are required.

| Component | Version | License |
| --- | --- | --- |
| Tesseract.js | 7.0.0 | Apache 2.0 |
| Tesseract.js Core | 7.0.0 | Apache 2.0 |
| Tesseract English trained data | Debian Tesseract 5 English package | Apache 2.0; see model notice |
| Nimbus Sans / Nimbus Sans Narrow | URW Base35 system distribution | AGPL 3 with font exception; see full notice |

Full bundled notices are in the licenses folder. Fonts are unmodified; heading condensation is applied in CSS. The cat, paws, and app UI icons are native SVG assets created to match the supplied visual reference.

Development references:

- https://github.com/naptha/tesseract.js
- https://github.com/naptha/tesseract.js/blob/master/docs/local-installation.md
- https://developer.android.com/develop/ui/views/layout/webapps/load-local-content
- https://developer.android.com/build/releases/agp-8-7-0-release-notes
- https://services.gradle.org/distributions/
