/**
 * Deterministic, explainable checks. No requests are made to a website or service.
 * Points are an internal triage weight, never a probability that something is a scam.
 */
export const ENGINE_VERSION = '2.0';
export const MAX_TEXT = 20000;
export const KINDS = ['message', 'link', 'job'];
const SHORTENERS = new Set(['bit.ly', 'tinyurl.com', 't.co', 'cutt.ly', 'is.gd', 'rb.gy', 'shorturl.at', 'rebrand.ly', 'ow.ly', 'buff.ly']);
const BRANDS = [
  ['paypal', ['paypal.com']], ['amazon', ['amazon.com', 'amazon.co.uk', 'amazon.in', 'amazon.ae']],
  ['microsoft', ['microsoft.com', 'live.com', 'office.com', 'outlook.com']],
  ['google', ['google.com', 'google.lk', 'google.co.uk', 'googleusercontent.com']],
  ['apple', ['apple.com', 'icloud.com']], ['facebook', ['facebook.com', 'fb.com']],
  ['instagram', ['instagram.com']], ['whatsapp', ['whatsapp.com']],
  ['netflix', ['netflix.com']], ['binance', ['binance.com']],
  ['dhl', ['dhl.com']], ['fedex', ['fedex.com']],
  ['linkedin', ['linkedin.com']]
];

export class InputError extends Error {}
const flag = (id, title, detail, weight, evidence = '') => ({ id, title, detail, weight, evidence: evidence.slice(0, 140) });
const hostIs = (host, domain) => host === domain || host.endsWith('.' + domain);

export function normalizeText(value) {
  return String(value ?? '').normalize('NFKC').replace(/[\u200B-\u200D\uFEFF]/g, '').replace(/\r\n?/g, '\n').trim();
}

export function parseLink(value) {
  let text = normalizeText(value);
  if (!text || text.length > 4096 || /\s/.test(text)) throw new InputError('Enter one complete link without spaces.');
  text = text.replace(/^hxxps:/i, 'https:').replace(/^hxxp:/i, 'http:').replace(/\[\.\]|\(\.\)/g, '.');
  if (!/^[a-z][a-z\d+.-]*:/i.test(text)) text = 'https://' + text;
  let url;
  try { url = new URL(text); } catch { throw new InputError('Enter a valid website link, such as example.com.'); }
  if (!['http:', 'https:'].includes(url.protocol)) throw new InputError('Use a website link beginning with http:// or https://.');
  const hostname = url.hostname.toLowerCase().replace(/\.$/, '');
  if (!hostname || (!hostname.includes('.') && !hostname.includes(':')) || hostname.includes('..')) {
    throw new InputError('Enter a complete website address, such as example.com.');
  }
  return { url, hostname, input: normalizeText(value), display: hostname + (url.port ? ':' + url.port : '') };
}

export function extractLinks(text) {
  const normalized = normalizeText(text).replace(/\[\.\]|\(\.\)/g, '.');
  const matches = normalized.match(/(?:https?|hxxps?):\/\/[^\s<>"']+|(?:www\.)[^\s<>"']+|(?<![@\w.-])(?:[a-z\d](?:[a-z\d-]{0,61}[a-z\d])?\.)+[a-z]{2,24}(?:\/[^\s<>"']*)?/gi) || [];
  const links = [];
  for (const match of matches.slice(0, 20)) {
    const candidate = match.replace(/[.,;!?)\]}]+$/, '');
    try {
      const parsed = parseLink(candidate);
      if (!links.some(x => x.url.href === parsed.url.href)) links.push(parsed);
    } catch { /* Invalid snippets are not treated as verified links. */ }
  }
  return links;
}

function inspectLink(parsed) {
  const { url, hostname, input } = parsed;
  const out = [];
  if (url.username || url.password) out.push(flag('url-credentials', 'The link hides its destination', 'Text before @ is not the website. The actual destination is ' + hostname + '.', 48, hostname));
  if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(hostname) || hostname.includes(':')) out.push(flag('url-ip', 'A numeric address replaces a domain', 'An IP address can conceal who operates a link. Confirm the source independently.', 18, hostname));
  if (url.protocol === 'http:') out.push(flag('url-http', 'The link uses an unencrypted connection', 'HTTP does not protect information in transit. HTTPS alone would not prove a site is trustworthy.', 12, 'http://'));
  if (hostname.split('.').some(part => part.startsWith('xn--'))) out.push(flag('url-unicode', 'The domain uses international characters', 'Look-alike letters can imitate another domain. Check the complete address carefully.', 18, hostname));
  if (SHORTENERS.has(hostname)) out.push(flag('url-shortened', 'A shortened link hides the final site', 'The destination cannot be checked from this address while offline.', 20, hostname));
  if (url.port && !['80', '443'].includes(url.port)) out.push(flag('url-port', 'An unusual website port is used', 'Confirm that the sender intended this exact address and port.', 10, url.port));
  if (/\.(?:apk|exe|msi|scr|bat|cmd|ps1|dmg)(?:$|[?#])/i.test(url.pathname + url.search)) {
    out.push(flag('url-download', 'The link points to an installable file', 'An unexpected app or executable can take control of a device. Do not install it to receive money or support.', 40, url.pathname.split('/').pop()));
  }
  for (const [brand, domains] of BRANDS) {
    if (hostname.includes(brand) && !domains.some(domain => hostIs(hostname, domain))) {
      out.push(flag('url-brand-' + brand, 'A brand name appears in a different domain', 'This address contains “' + brand + '” but is not one of its recognized domains. Verify the exact address through the official app.', 35, hostname));
    }
  }
  if (hostname.split('.').length >= 5) out.push(flag('url-subdomains', 'The address has many subdomains', 'Long addresses can place a familiar name far away from the actual site operator.', 10, hostname));
  if (/\b(?:password|passwd|otp|pin|cvv|secret)\b/i.test(url.search)) out.push(flag('url-sensitive', 'Sensitive information appears in the link', 'Passwords, PINs, and one-time codes should not be included in a URL.', 30, 'Sensitive query field'));
  if (/\[\.\]|hxxp/i.test(input)) out.push(flag('url-obfuscated', 'The address was deliberately altered', 'The link uses obfuscated punctuation. This can be used to discuss a dangerous address without making it clickable.', 4, input));
  return out;
}

function positiveMatch(text, expression) {
  const match = expression.exec(text);
  if (!match) return null;
  const before = text.slice(Math.max(0, match.index - 48), match.index);
  const statement = before.slice(Math.max(before.lastIndexOf('.'), before.lastIndexOf('!'), before.lastIndexOf('?'), before.lastIndexOf('\n')) + 1);
  if (/\b(?:never|do not|don't|will not|won't|must not|should not|not to|avoid)\b[^.!?\n]{0,42}$/i.test(statement)) return null;
  return match[0];
}

function inspectText(text, kind) {
  const out = [];
  const add = (id, title, detail, weight, pattern, negate = true) => {
    const evidence = negate ? positiveMatch(text, pattern) : pattern.exec(text)?.[0];
    if (evidence) out.push(flag(id, title, detail, weight, evidence));
  };
  add('secret-request', 'A private code or password is requested', 'A one-time code, password, PIN, or CVV can give someone access to your account.', 62, /\b(?:send|share|tell|provide|read(?: out)?|give|reply with|confirm|enter)\b[^.!?\n]{0,65}\b(?:otp|one[- ]time (?:password|code)|verification code|password|pin|cvv|recovery (?:code|phrase)|seed phrase)\b/i);
  add('remote-access', 'Remote access or screen sharing is requested', 'Unexpected support asking for remote-control software can gain access to your device and banking activity.', 60, /\b(?:install|download|open|use|connect (?:to|with))\b[^.!?\n]{0,55}\b(?:anydesk|teamviewer|rustdesk|remote (?:access|desktop|support)|screen[- ]?shar(?:e|ing))\b/i);
  add('prize-fee', 'Money is needed to release a prize', 'A payment to claim a lottery, giveaway, inheritance, or prize is a strong scam warning.', 65, /\b(?:pay|send|deposit|transfer)\b[^.!?\n]{0,100}\b(?:prize|lottery|winnings|inheritance|giveaway)\b|\b(?:prize|lottery|winnings|inheritance)\b[^.!?\n]{0,100}\b(?:fee|pay|deposit|tax|transfer)\b/i);
  add('guaranteed-return', 'Guaranteed investment returns are promised', 'Claims of certain profit or risk-free high returns are unreliable. Check the provider independently.', 55, /\b(?:guaranteed|risk[- ]?free|no risk|100% (?:safe|profit))\b[^.!?\n]{0,70}\b(?:profit|returns?|investment|income|crypto|trading)\b|\b(?:double|triple)\s+(?:your\s+)?(?:money|investment)\b/i);
  add('unusual-payment', 'An unusual payment method is requested', 'Gift cards and cryptocurrency transfers can be difficult to recover when sent to an unknown person.', 38, /\b(?:pay|send|buy|transfer|deposit)\b[^.!?\n]{0,60}\b(?:gift cards?|bitcoin|usdt|crypto(?:currency)?|wallet address)\b/i);
  add('bank-transfer', 'You are told to move money for safety', 'An unexpected instruction to move funds to a “safe” or “secure” account is a strong impersonation warning.', 65, /\b(?:move|transfer|send)\b[^.!?\n]{0,70}\b(?:safe|secure|holding)\s+(?:bank\s+)?account\b/i);
  add('threat', 'A threat pressures you to act', 'Threats of arrest, a police case, or leaked personal material are often used to demand fast payment.', 40, /\b(?:arrest warrant|you will be arrested|police (?:case|investigation)|leak your|release your (?:photos|video)|legal action against you)\b/i);
  add('account-pressure', 'An account problem creates pressure', 'An unexpected suspension or closure notice can push you into using a fraudulent login page.', 28, /\b(?:account|card|wallet)\b[^.!?\n]{0,45}\b(?:suspended|blocked|locked|terminated|closed|deactivated)\b|\b(?:suspended|blocked|locked)\b[^.!?\n]{0,30}\b(?:account|card|wallet)\b/i);
  add('urgency', 'The message demands an immediate response', 'Urgency reduces the time you have to verify who is contacting you.', 13, /\b(?:act now|immediately|urgent(?:ly)?|within (?:\d+|one|two|24) (?:minutes?|hours?)|last warning|final notice)\b/i);
  add('unexpected-prize', 'An unexpected prize is announced', 'If you did not enter a competition, independently verify the organizer before responding.', 25, /\b(?:you(?:'ve| have)? (?:won|been selected)|congratulations[^.!?\n]{0,45}(?:winner|won|prize))\b/i);
  add('delivery-fee', 'A delivery problem asks for a payment', 'Small redelivery charges can be used to collect card details. Check the shipment in the carrier’s official app.', 28, /\b(?:parcel|package|delivery|shipment)\b[^.!?\n]{0,85}\b(?:fee|pay|payment|card details|customs charge)\b/i);
  add('secrecy', 'You are told to keep it secret', 'Pressure to hide a payment or conversation prevents others from helping you verify it.', 24, /\b(?:do not tell anyone|don't tell anyone|keep (?:this|it) (?:a )?secret|keep this confidential)\b/i, false);
  if (kind === 'job' || /\b(?:job offer|recruiter|recruitment|hiring|employment|work from home|salary)\b/i.test(text)) {
    add('job-fee', 'A fee is required to get the job', 'Upfront recruitment, training, registration, equipment, or visa payments to an unverified recruiter need independent verification.', 64, /\b(?:pay|send|deposit|transfer)\b[^.!?\n]{0,90}\b(?:registration|training|recruitment|visa|equipment|security|processing|application)\b|\b(?:registration|training|recruitment|visa|equipment|security|processing|application)\s+(?:fee|deposit|payment)\b/i);
    add('job-task', 'A deposit is needed to unlock work or earnings', 'Task schemes may show fake earnings and then demand deposits to complete work or withdraw money.', 65, /\b(?:deposit|top[- ]?up|recharge|pay)\b[^.!?\n]{0,75}\b(?:tasks?|withdraw|unlock|commission|earnings)\b|\b(?:tasks?|withdraw|commission)\b[^.!?\n]{0,75}\b(?:deposit|top[- ]?up|recharge)\b/i);
    add('job-no-interview', 'The offer skips normal hiring checks', 'An offer with no interview or experience requirement should be checked against the employer’s actual careers page.', 20, /\b(?:no interview|without (?:an? )?interview|no experience (?:needed|required)|instant (?:hiring|job|approval))\b/i);
    add('job-private-chat', 'Hiring moves to a private chat account', 'Messaging apps are also used by legitimate recruiters. Verify the employer before sending documents or money.', 12, /\b(?:contact|message|join|reply|interview|recruiter|hr)\b[^.!?\n]{0,60}\b(?:telegram|whatsapp)\b/i);
    add('job-id', 'Identity documents are requested early', 'Verify the employer and the hiring stage before sharing passport, ID, or banking details.', 20, /\b(?:send|share|provide|upload)\b[^.!?\n]{0,60}\b(?:passport|national id|identity card|bank (?:account|details))\b/i);
  }
  return out;
}

function dedupe(flags) {
  return [...new Map(flags.map(item => [item.id + ':' + (item.id.startsWith('url-') ? item.evidence : ''), item])).values()];
}

export function analyze(input, kind = 'message') {
  if (!KINDS.includes(kind)) throw new InputError('Choose a message, link, or job check.');
  const text = normalizeText(input);
  if (!text) throw new InputError(kind === 'link' ? 'Paste a link to check.' : 'Paste the text you want to check.');
  if (text.length > MAX_TEXT) throw new InputError('Keep the text below 20,000 characters.');
  if (kind !== 'link' && text.length < 8) throw new InputError('Add a little more text so there is enough to check.');
  const links = kind === 'link' ? [parseLink(text)] : extractLinks(text);
  const findings = dedupe([
    ...(kind === 'link' ? [] : inspectText(text, kind)),
    ...links.flatMap(inspectLink)
  ]).sort((a, b) => b.weight - a.weight);
  const points = Math.min(99, findings.reduce((total, item) => total + item.weight, 0));
  const enoughText = kind === 'link' || (text.length >= 25 && text.split(/\s+/).length >= 4);
  const level = points >= 55 ? 'high' : points >= 20 ? 'medium' : findings.length ? 'caution' : enoughText ? 'low' : 'unclear';
  const recommendations = [];
  if (findings.some(f => ['secret-request', 'remote-access', 'bank-transfer'].includes(f.id))) recommendations.push('Stop the conversation. Use the official app or a phone number you already know to contact the organization.');
  if (findings.some(f => /fee|payment|return|task/.test(f.id))) recommendations.push('Pause any payment. Verify the person or company independently before sending money.');
  if (kind === 'job') recommendations.push('Find the vacancy on the employer’s own careers page and contact its published recruitment team.');
  if (links.length) recommendations.push('Open the organization’s official app or type its known address yourself. This check did not open the link or inspect the website.');
  if (!recommendations.length) recommendations.push('Verify unexpected requests through a separate contact you trust before acting.');
  return {
    engineVersion: ENGINE_VERSION, kind, text, level,
    findings: findings.map(({ weight, ...item }) => item),
    domains: [...new Set(links.map(link => link.display))],
    recommendations: [...new Set(recommendations)].slice(0, 3),
    limitation: kind === 'link'
      ? 'Only the address was checked. Website content, ownership, redirects, and reputation were not verified.'
      : 'Offline rules can miss scams and flag legitimate messages. No warning signs does not prove something is safe.',
    enoughText
  };
}
