const HISTORY_KEY = 'scamsense.history.v2';
const SETTINGS_KEY = 'scamsense.settings.v2';
const MAX_HISTORY = 100;
const DEFAULT_SETTINGS = { saveHistory: true };
export function createStore(storage) {
  let memory = { records: [], settings: { ...DEFAULT_SETTINGS } };
  let persistent = Boolean(storage);
  try {
    storage?.setItem('scamsense.probe', '1');
    storage?.removeItem('scamsense.probe');
  } catch { persistent = false; }
  function read(key, fallback) {
    if (!persistent) return fallback;
    try { return JSON.parse(storage.getItem(key)) ?? fallback; } catch { return fallback; }
  }
  function write(key, value) {
    if (!persistent) return false;
    try { storage.setItem(key, JSON.stringify(value)); return true; }
    catch { persistent = false; return false; }
  }
  memory.settings = { ...DEFAULT_SETTINGS, ...read(SETTINGS_KEY, {}) };
  const loaded = read(HISTORY_KEY, []);
  memory.records = Array.isArray(loaded) ? loaded.filter(isRecord).slice(0, MAX_HISTORY) : [];
  return {
    get persistent() { return persistent; },
    get settings() { return { ...memory.settings }; },
    get records() { return [...memory.records]; },
    setSaveHistory(enabled) {
      memory.settings.saveHistory = Boolean(enabled);
      write(SETTINGS_KEY, memory.settings);
    },
    add(result) {
      if (!memory.settings.saveHistory) return null;
      const id = globalThis.crypto?.randomUUID?.() || Date.now().toString(36) + Math.random().toString(36).slice(2);
      const record = { id, createdAt: new Date().toISOString(), kind: result.kind, text: result.text, level: result.level };
      memory.records = [record, ...memory.records].slice(0, MAX_HISTORY);
      write(HISTORY_KEY, memory.records);
      return record;
    },
    remove(id) { memory.records = memory.records.filter(r => r.id !== id); write(HISTORY_KEY, memory.records); },
    clear() { memory.records = []; write(HISTORY_KEY, []); },
    export() { return JSON.stringify({ app: 'ScamSense', version: 2, exportedAt: new Date().toISOString(), records: memory.records }, null, 2); },
    import(text) {
      const data = JSON.parse(text);
      if (data?.app !== 'ScamSense' || data.version !== 2 || !Array.isArray(data.records) || !data.records.every(isRecord)) throw new Error('Choose a valid ScamSense v2 backup.');
      const merged = new Map(memory.records.map(r => [r.id, r]));
      for (const record of data.records.slice(0, MAX_HISTORY)) {
        merged.set(record.id, { id: record.id, createdAt: record.createdAt, kind: record.kind, text: record.text, level: record.level });
      }
      memory.records = [...merged.values()].sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt)).slice(0, MAX_HISTORY);
      write(HISTORY_KEY, memory.records);
      return memory.records.length;
    }
  };
}
function isRecord(record) {
  return record && typeof record.id === 'string' && record.id.length <= 100 &&
    typeof record.text === 'string' && record.text.length <= 20000 &&
    ['message', 'link', 'job'].includes(record.kind) &&
    ['high', 'medium', 'caution', 'low', 'unclear'].includes(record.level) &&
    typeof record.createdAt === 'string' && Number.isFinite(Date.parse(record.createdAt));
}
