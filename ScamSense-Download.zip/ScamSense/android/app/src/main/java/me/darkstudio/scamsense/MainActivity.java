package me.darkstudio.scamsense;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Base64;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** A permission-free, local-only Android host for the bundled ScamSense app. */
public class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String HOME = "https://" + HOST + "/index.html";
    private static final int PICK_FILE = 100, SAVE_BACKUP = 101;
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingBackup;
    private Intent pendingShare;
    private boolean ready = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        getWindow().setStatusBarColor(Color.rgb(29, 29, 29));
        getWindow().setNavigationBarColor(Color.rgb(29, 29, 29));
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(29, 29, 29));
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        // Respect status/navigation bars and the on-screen keyboard on API 35.
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                android.graphics.Insets keyboard = insets.getInsets(WindowInsets.Type.ime());
                view.setPadding(bars.left, bars.top, bars.right, Math.max(bars.bottom, keyboard.bottom));
                return insets;
            });
        } else {
            root.setFitsSystemWindows(true);
            root.setSystemUiVisibility(0);
        }
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        settings.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptCookie(false);
        web.setBackgroundColor(Color.rgb(29, 29, 29));
        web.addJavascriptInterface(new AppBridge(), "AppHost");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                return !"https".equals(uri.getScheme()) || !HOST.equals(uri.getHost());
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!"https".equals(uri.getScheme()) || !HOST.equals(uri.getHost()) || !"GET".equals(request.getMethod())) return blocked(403, "Blocked");
                String path = uri.getPath();
                if (path == null || path.contains("..") || path.contains("\\") || path.indexOf('\0') >= 0) return blocked(403, "Blocked");
                path = path.equals("/") ? "index.html" : path.replaceFirst("^/", "");
                try {
                    InputStream bytes = getAssets().open(path);
                    Map<String,String> headers = new HashMap<>();
                    headers.put("Cache-Control", "no-store");
                    headers.put("X-Content-Type-Options", "nosniff");
                    return new WebResourceResponse(mime(path), isText(path) ? "UTF-8" : null, 200, "OK", headers, bytes);
                } catch (Exception error) { return blocked(404, "Not found"); }
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (url.startsWith(HOME)) { ready = true; deliverShare(); }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent picker = params.createIntent();
                    picker.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(picker, PICK_FILE);
                } catch (ActivityNotFoundException error) {
                    fileCallback.onReceiveValue(null); fileCallback = null;
                    toast("No file picker is available on this device.");
                }
                return true;
            }
        });
        if (Intent.ACTION_SEND.equals(getIntent().getAction())) pendingShare = getIntent();
        web.loadUrl(HOME);
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent); setIntent(intent);
        if (Intent.ACTION_SEND.equals(intent.getAction())) { pendingShare = intent; deliverShare(); }
    }
    private void deliverShare() {
        if (!ready || pendingShare == null) return;
        Intent share = pendingShare; pendingShare = null;
        if ("text/plain".equals(share.getType())) {
            CharSequence text = share.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if (text != null) {
                String value = text.toString();
                if (value.length() > 20000) value = value.substring(0, 20000);
                web.evaluateJavascript("window.ScamSense.receiveText(" + JSONObject.quote(value) + ")", null);
            }
        } else if (share.getType() != null && share.getType().startsWith("image/")) {
            Uri uri = share.getParcelableExtra(Intent.EXTRA_STREAM);
            if (uri == null) return;
            new Thread(() -> {
                try (InputStream input = getContentResolver().openInputStream(uri)) {
                    if (input == null) throw new Exception("No image");
                    ByteArrayOutputStream output = new ByteArrayOutputStream();
                    byte[] buffer = new byte[8192];
                    int read;
                    while ((read = input.read(buffer)) != -1) {
                        if (output.size() + read > 10 * 1024 * 1024) throw new Exception("Image too large");
                        output.write(buffer, 0, read);
                    }
                    String type = getContentResolver().getType(uri);
                    if ("image/jpg".equals(type)) type = "image/jpeg";
                    if (type == null || !(type.equals("image/png") || type.equals("image/jpeg") || type.equals("image/webp") || type.equals("image/bmp"))) throw new Exception("Unsupported image");
                    String data = "data:" + type + ";base64," + Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP);
                    runOnUiThread(() -> web.evaluateJavascript("window.ScamSense.receiveImage(" + JSONObject.quote(data) + ",'shared-screenshot')", null));
                } catch (Exception error) { runOnUiThread(() -> toast("Choose a PNG, JPG, WebP or BMP image under 10 MB.")); }
            }, "ScamSense-image-import").start();
        }
    }
    public final class AppBridge {
        @JavascriptInterface public void saveBackup(String data) {
            if (data == null || data.length() > 4 * 1024 * 1024) return;
            runOnUiThread(() -> {
                pendingBackup = data;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "ScamSense-Backup-" + new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()) + ".json");
                try { startActivityForResult(intent, SAVE_BACKUP); }
                catch (ActivityNotFoundException error) { pendingBackup = null; toast("A document picker is unavailable."); }
            });
        }
        @JavascriptInterface public void shareText(String text) {
            if (text == null || text.length() > 30000) return;
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_TEXT, text);
                try { startActivity(Intent.createChooser(intent, "Share ScamSense result")); }
                catch (ActivityNotFoundException error) { toast("No sharing app is available."); }
            });
        }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            fileCallback = null;
        }
        if (requestCode == SAVE_BACKUP) {
            String backup = pendingBackup; pendingBackup = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null && backup != null) {
                try (OutputStream output = getContentResolver().openOutputStream(data.getData())) {
                    if (output == null) throw new Exception("No output");
                    output.write(backup.getBytes(StandardCharsets.UTF_8));
                    toast("Backup saved.");
                } catch (Exception error) { toast("The backup could not be saved."); }
            }
        }
    }
    @Override public void onBackPressed() {
        web.evaluateJavascript("window.ScamSense ? window.ScamSense.back() : false", value -> {
            if (!"true".equals(value)) finish();
        });
    }
    @Override protected void onPause() { web.onPause(); super.onPause(); }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }
    @Override protected void onDestroy() {
        if (fileCallback != null) fileCallback.onReceiveValue(null);
        web.removeJavascriptInterface("AppHost");
        web.destroy();
        super.onDestroy();
    }
    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_SHORT).show(); }
    private static WebResourceResponse blocked(int status, String reason) {
        return new WebResourceResponse("text/plain", "UTF-8", status, reason, new HashMap<>(),
            new ByteArrayInputStream(reason.getBytes(StandardCharsets.UTF_8)));
    }
    private static boolean isText(String path) { return path.endsWith(".html") || path.endsWith(".js") || path.endsWith(".css") || path.endsWith(".json") || path.endsWith(".svg") || path.endsWith(".webmanifest"); }
    private static String mime(String path) {
        if (path.endsWith(".html")) return "text/html";
        if (path.endsWith(".js")) return "text/javascript";
        if (path.endsWith(".css")) return "text/css";
        if (path.endsWith(".svg")) return "image/svg+xml";
        if (path.endsWith(".json")) return "application/json";
        if (path.endsWith(".webmanifest")) return "application/manifest+json";
        if (path.endsWith(".png")) return "image/png";
        if (path.endsWith(".otf")) return "font/otf";
        if (path.endsWith(".wasm")) return "application/wasm";
        return "application/octet-stream";
    }
}
