@echo off
node "%~dp0..\tools\android-build.mjs" %*
