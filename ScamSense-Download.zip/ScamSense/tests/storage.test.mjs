import test from 'node:test';
import assert from 'node:assert/strict';
import { createStore } from '../web/storage.js';
const mockStorage = () => {
  const entries = new Map();
  return { getItem: k => entries.get(k) ?? null, setItem: (k, v) => entries.set(k, v), removeItem: k => entries.delete(k) };
};
const result = { kind: 'message', text: 'A sufficiently long ordinary message.', level: 'low' };
test('history survives reloading the store', () => {
  const storage = mockStorage();
  createStore(storage).add(result);
  assert.equal(createStore(storage).records.length, 1);
});
test('history setting stops new records', () => {
  const store = createStore(mockStorage());
  store.setSaveHistory(false);
  store.add(result);
  assert.equal(store.records.length, 0);
});
test('individual and bulk deletion work', () => {
  const store = createStore(mockStorage());
  const a = store.add(result);
  store.add(result);
  store.remove(a.id);
  assert.equal(store.records.length, 1);
  store.clear();
  assert.equal(store.records.length, 0);
});
test('backup round trip merges without duplicates', () => {
  const a = createStore(mockStorage());
  a.add(result);
  const b = createStore(mockStorage());
  b.import(a.export());
  b.import(a.export());
  assert.equal(b.records.length, 1);
  assert.equal(b.records[0].text, result.text);
});
test('invalid imports leave existing records untouched', () => {
  const store = createStore(mockStorage());
  store.add(result);
  assert.throws(() => store.import('{"app":"ScamSense","version":2,"records":[{"id":"broken"}]}'));
  assert.equal(store.records.length, 1);
});
test('blocked storage falls back to session memory', () => {
  const store = createStore({ setItem() { throw new Error('blocked'); } });
  assert.equal(store.persistent, false);
  store.add(result);
  assert.equal(store.records.length, 1);
});
