import test from 'node:test';
import assert from 'node:assert/strict';
import { analyze, parseLink, extractLinks, InputError, normalizeText } from '../web/engine.js';
const ids = result => result.findings.map(f => f.id);
test('asks for an OTP: high warning with an explanation', () => {
  const result = analyze('Your bank account is blocked. Send your OTP immediately to reactivate it.');
  assert.equal(result.level, 'high');
  assert.ok(ids(result).includes('secret-request'));
  assert.ok(result.findings[0].detail);
});
test('negative security advice is not a request for a code', () => {
  const result = analyze('We will never ask you to share your OTP or password. Stay alert online.');
  assert.ok(!ids(result).includes('secret-request'));
});
test('do not install remote-control advice is not treated as a request', () => {
  assert.ok(!ids(analyze('Do not install AnyDesk when an unknown person asks you to.')).includes('remote-access'));
});
test('a new sentence after negative advice is still checked', () => {
  assert.ok(ids(analyze('Never trust strangers. Send your OTP to confirm your prize.')).includes('secret-request'));
});
test('upfront job fees are flagged', () => {
  const result = analyze('Congratulations on the job offer. Pay a registration fee of Rs 5000 before starting work.', 'job');
  assert.equal(result.level, 'high');
  assert.ok(ids(result).includes('job-fee'));
});
test('task deposit schemes are flagged', () => {
  assert.ok(ids(analyze('You must top up your balance to unlock tasks and withdraw commission.', 'job')).includes('job-task'));
});
test('ordinary interview invitation has no invented findings', () => {
  const result = analyze('Thank you for applying. Your interview is on Tuesday at our office. Please bring your portfolio.', 'job');
  assert.equal(result.level, 'low');
  assert.equal(result.findings.length, 0);
});
test('brand embedded in attacker domain is detected', () => {
  const result = analyze('https://paypal.com.evil.example/login', 'link');
  assert.ok(ids(result).includes('url-brand-paypal'));
  assert.deepEqual(result.domains, ['paypal.com.evil.example']);
});
test('official subdomain is not treated as brand impersonation', () => {
  assert.ok(!ids(analyze('https://www.paypal.com/signin', 'link')).includes('url-brand-paypal'));
});
test('userinfo is not confused with the real hostname', () => {
  const result = analyze('https://paypal.com@evil.example/login', 'link');
  assert.ok(ids(result).includes('url-credentials'));
  assert.deepEqual(result.domains, ['evil.example']);
});
test('shortened HTTPS address is not declared safe', () => {
  assert.equal(analyze('https://bit.ly/example', 'link').level, 'medium');
});
test('an HTTPS address is not a site reputation verdict', () => {
  const result = analyze('https://unknown.example/path', 'link');
  assert.equal(result.level, 'low');
  assert.match(result.limitation, /not verified/);
  assert.ok(!('probability' in result));
});
test('punycode and numeric addresses have transparent explanations', () => {
  assert.ok(ids(analyze('https://xn--pple-43d.com', 'link')).includes('url-unicode'));
  assert.ok(ids(analyze('http://192.0.2.1', 'link')).includes('url-ip'));
});
test('download warning survives query parameters', () => {
  assert.ok(ids(analyze('https://example.com/support.apk?download=1', 'link')).includes('url-download'));
});
test('obfuscated links normalize without opening them', () => {
  assert.equal(parseLink('hxxps://example[.]com/test').hostname, 'example.com');
});
test('multiple message links are individually checked', () => {
  assert.equal(extractLinks('Compare https://example.com and https://bit.ly/x.').length, 2);
  assert.ok(ids(analyze('Check these links https://example.com and https://bit.ly/x.')).includes('url-shortened'));
});
test('email address alone is not a website link', () => {
  assert.equal(extractLinks('Please contact recruitment@example.com tomorrow.').length, 0);
});
test('malformed, local, and non-web links are rejected', () => {
  for (const link of ['javascript:alert(1)', 'file:///etc/passwd', 'not a url', 'localhost', 'https://']) {
    assert.throws(() => analyze(link, 'link'), InputError);
  }
});
test('missing and excessively large content are rejected', () => {
  assert.throws(() => analyze(' '), InputError);
  assert.throws(() => analyze('x'.repeat(20001)), InputError);
});
test('too little context is distinct from no warning signs', () => {
  assert.equal(analyze('hello there').level, 'unclear');
});
test('invisible characters do not evade matching', () => {
  assert.equal(normalizeText('a\u200Bb'), 'ab');
  assert.ok(ids(analyze('Please send your O\u200BTP to our officer.')).includes('secret-request'));
});
test('same input gives the same explanation', () => {
  assert.deepEqual(analyze('Urgent: your account is suspended. Share your password now.'), analyze('Urgent: your account is suspended. Share your password now.'));
});
