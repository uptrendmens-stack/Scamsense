import { cp, mkdir, readFile, readdir, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { resolve, join } from 'node:path';
const root = fileURLToPath(new URL('..', import.meta.url));
async function files(dir, prefix = '') {
  const output = [];
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const name = prefix + entry.name;
    if (entry.isDirectory()) output.push(...await files(join(dir, entry.name), name + '/'));
    else if (!['sw.js', 'precache.json'].includes(name)) output.push(name);
  }
  return output.sort();
}
const web = resolve(root, 'web');
const all = await files(web);
const hash = createHash('sha256');
for (const name of all) hash.update(await readFile(join(web, name)));
const version = hash.digest('hex').slice(0, 12);
await writeFile(join(web, 'precache.json'), JSON.stringify({ version, files: all }, null, 2) + '\n');
const workerPath = join(web, 'sw.js');
const worker = await readFile(workerPath, 'utf8');
await writeFile(workerPath, worker.replace(/const BUILD_VERSION = '[^']+';/, "const BUILD_VERSION = '" + version + "';"));
if (!process.argv.includes('--android')) {
  await mkdir(resolve(root, 'dist'), { recursive: true });
  await cp(web, resolve(root, 'dist'), { recursive: true });
  console.log('Built dist/. All runtime assets, fonts and OCR data are local.');
} else {
  console.log('Android uses the shared web/ source directly. Offline asset manifest refreshed.');
}
