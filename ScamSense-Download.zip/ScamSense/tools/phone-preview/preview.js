const stage = document.querySelector('.preview-stage');
const screen = document.querySelector('#phone-screen');

function fitPhone() {
  const scale = Math.max(.1, Math.min(1, (window.innerWidth - 40) / 406, (window.innerHeight - 40) / 860));
  stage.style.setProperty('--scale', String(scale));
}

fitPhone();
window.addEventListener('resize', fitPhone, { passive: true });

// The frame loads the Android app assets and leaves navigation inside the app.
screen.src = '/index.html' + location.hash;
