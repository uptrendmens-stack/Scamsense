import { readFile, access } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('..', import.meta.url));
const required = ['index.html', 'app.js', 'engine.js', 'storage.js', 'styles.css', 'sw.js', 'manifest.webmanifest', 'assets/cat.svg', 'assets/paw.svg', 'assets/icons.svg', 'assets/icon-192.png', 'assets/icon-512.png', 'assets/fonts/NimbusSansNarrow-Bold.otf', 'assets/fonts/NimbusSans-Regular.otf', 'vendor/ocr/tesseract.min.js', 'vendor/ocr/worker.min.js', 'vendor/ocr/tesseract-core-lstm.wasm.js', 'vendor/ocr/tesseract-core-simd-lstm.wasm.js', 'vendor/ocr/eng.traineddata'];
required.push('vendor/ocr/tesseract-core-relaxedsimd-lstm.wasm.js');
for (const name of required) await access(root + '/web/' + name);
for (const name of ['index.html', 'preview.css', 'preview.js']) await access(root + '/tools/phone-preview/' + name);
for (const name of ['web/app.js', 'web/engine.js', 'web/storage.js', 'web/sw.js', 'tools/server.mjs', 'tools/phone-preview/preview.js']) {
  const result = spawnSync(process.execPath, ['--check', root + '/' + name], { stdio: 'inherit' });
  if (result.status) process.exit(result.status);
}
JSON.parse(await readFile(root + '/web/manifest.webmanifest', 'utf8'));
JSON.parse(await readFile(root + '/package.json', 'utf8'));
console.log('JavaScript syntax, manifests and required offline assets checked.');
