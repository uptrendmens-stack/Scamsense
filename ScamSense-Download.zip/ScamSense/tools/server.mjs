import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { resolve, extname, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('../web', import.meta.url));
const previewRoot = fileURLToPath(new URL('./phone-preview', import.meta.url));
const portArg = process.argv.indexOf('--port');
const port = Number((portArg >= 0 ? process.argv[portArg + 1] : null) || process.env.PORT || 5173);
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpeg': 'image/jpeg', '.jpg': 'image/jpeg', '.otf': 'font/otf', '.wasm': 'application/wasm', '.traineddata': 'application/octet-stream' };
const server = http.createServer(async (req, res) => {
  if (!['GET', 'HEAD'].includes(req.method)) { res.writeHead(405); res.end(); return; }
  let path;
  try { path = decodeURIComponent(new URL(req.url, 'http://localhost').pathname); }
  catch { res.writeHead(400); res.end('Invalid address'); return; }
  const isPhone = req.headers['sec-ch-ua-mobile'] === '?1' || /Android|iPhone|iPod|Mobile/i.test(req.headers['user-agent'] || '');
  let base = root;
  let relative = path === '/' ? '/index.html' : path;
  if (path === '/' && !isPhone) {
    base = previewRoot;
  } else if (path.startsWith('/__phone-preview/')) {
    base = previewRoot;
    relative = path.slice('/__phone-preview'.length);
  }
  const target = resolve(base, '.' + relative);
  if (!target.startsWith(base + sep)) { res.writeHead(403); res.end('Forbidden'); return; }
  try {
    if (!(await stat(target)).isFile()) throw new Error('Not a file');
    const bytes = await readFile(target);
    res.writeHead(200, {
      'Content-Type': mime[extname(target)] || 'application/octet-stream',
      'Content-Length': bytes.length, 'Cache-Control': 'no-cache',
      'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer'
    });
    res.end(req.method === 'HEAD' ? undefined : bytes);
  } catch { res.writeHead(404, { 'Content-Type': 'text/plain' }); res.end('Not found'); }
});
server.listen(port, '0.0.0.0', () => console.log('ScamSense is running at http://localhost:' + port));
for (const signal of ['SIGTERM', 'SIGINT']) process.on(signal, () => server.close(() => process.exit(0)));
